# SourceInsightTheme
Source Insight 4 Theme, Sublime style
![Sublime style theme](./SublimeStyle.PNG)
# Installation
Source Insight -> Option -> Load Configuration